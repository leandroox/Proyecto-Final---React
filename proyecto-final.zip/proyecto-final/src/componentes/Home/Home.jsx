import React from 'react';
import Header from './Header';
import Search from './Search';

function Home() {
    return (
        <>
            <Header />
            <Search />
        </>
    );

}

export default Home;