import React from 'react';


function Header() {
        return (
            <div className="header">
                <div id="grid-header">

                    <div id="text-header">
                        <h1>
                            Busca entre miles de imágenes!
                    </h1>
                        <p>Gracias a Unsplash, aqui puedes encontrar miles de imagenes<br></br> de la clase que necesites.</p>
                        <a href="https://unsplash.com/" target="_blank">
                            <button>Unsplash</button>
                        </a>
                    </div>

                    <div id="img-header">
                        <img src="./img/img-header.svg"></img>
                    </div>
                </div>
            </div>
        );
}

export default Header;