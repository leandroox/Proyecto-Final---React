import React, { useState } from 'react';


function Search() {

    const [value,setValue] = useState("")
    const [results,setResults] = useState([])
    const fetchImages = ()=>{
        fetch(`https://api.unsplash.com/search/photos/?client_id=zgiZh_efe75VuOjvoOOEBpqzJYycm7om5O6FSk95w50&query=${value}&orientation=squarish`)
        .then(res=>res.json())
        .then(data=>{
            console.log(data)
            setResults(data.results)
        })
    }

    return (
        <div className="search-container">
            <div id="search">
                <input
                    id="search-bar"
                    type="text"
                    placeholder="Busca las imagenes que necesites..."
                    value={value}
                    onChange={(e) => setValue(e.target.value)}>
                </input>
                <button onClick={()=>fetchImages()}>Buscar</button>
            </div>

            <div id="gallery">
                {
                    results.map((item)=>{
                        return <a href="https://unsplash.com/" target="_blank" id="box-img"><img key={item.id} src={item.urls.small} /></a>
                    })
                }
            </div>
        </div>
    )
}

export default Search;