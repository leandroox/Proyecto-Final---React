import React from 'react';
import { Link } from 'react-router-dom';

function Nav() {
    return (
        <div className="nav">
            <div id="social-nav">
                <a href="https://instagram.com" target="_blank"><span class="iconify" data-icon="entypo-social:instagram-with-circle"></span></a>
                <a href="https://twitter.com" target="_blank"><span class="iconify" data-icon="entypo-social:twitter-with-circle"></span></a>
                <a href="https://facebook.com" target="_blank"><span class="iconify" data-icon="entypo-social:facebook-with-circle"></span></a>
            </div>
            <div id="logo-nav">
                <Link to="/"><img src="./img/logo.svg"></img></Link>
            </div>

            <div id="user-nav">
                <Link to="/formulario"><span id="user-icon" className="iconify" data-icon="bx:bxs-user-circle"></span></Link>
            </div>
        </div>
    );
}
export default Nav;