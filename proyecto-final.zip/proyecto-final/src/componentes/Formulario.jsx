import React from 'react';

function Formulario() {
    return (
        <div className="formulario">
            <div id="form-container">

                <form>
                    <span id="user-icon" className="iconify" data-icon="bx:bxs-user-circle"></span>

                    <input type="text" placeholder="Correo electrónico"></input>

                    <input type="text" placeholder="Usuario"></input>

                    <input type="text" placeholder="Contraseña"></input>

                    <input type="text" placeholder="Repetir contraseña"></input>

                    <button>Registrarse</button>
                </form>
                <div id="form-text">
                    <p>Ya tienes una cuenta?</p> <a>Inicia Sesión</a>
                </div>

            </div>
        </div>
    );
}

export default Formulario;